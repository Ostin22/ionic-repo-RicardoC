package com.puce.registroapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
